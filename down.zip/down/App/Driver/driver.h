#ifndef __DRIVER_H_
#define __DRIVER_H_
/************************************** Includes **************************************/
#include "drv_can.h"
#include "drv_usart.h"
/********************************* Exported functions *********************************/
void Driver_Init(void);
#endif
