#ifndef __SYSTEM_TASK_H
#define	__SYSTEM_TASK_H


void Time_Init(void);
void System_State(void);


#endif
