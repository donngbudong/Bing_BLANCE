/***      
�� ���̿��ƴ��� ��
***/
#include "chassis_task.h"
#include "Device.h"


/* Init start */
CHASSIS_Date_t Chassis ={
	.State=SYSTEM_LOST,
	.Ctrl_Mode = Ctrl_Err,
	.PID_Type = RC,
};




/**
 * @brief �����ܿ�
 * @param 
 */
uint8_t  s11= 1;
uint8_t  s22= 2;

void Chassis_Task(void)
{
//	Chassis.omega_z = 2;
	Chassis_GET_Info();
//	CAN_cmd_RC(s11,s22);
	if(RC_S2 == 1)
	{
		Chassis_Balance();
		CAN_cmd_chassis(Chassis.iqControl[0],Chassis.iqControl[1]);
	}
	if(RC_S2 == 2)
	{
		Chassis_Normal();
		CAN_cmd_chassis(Chassis.iqControl[0],Chassis.iqControl[1]);
	}
	else{
		Chassis_Stop();
		CAN_cmd_capacitance(300);
	}
}



/**
* @brief ������Ϣ��ȡ
* @param 
*/
float angle;
void Chassis_GET_Info(void)
{
	Chassis.torque_const = 2;		//ת��ϵ��
	Chassis.State	= System.System_State;

	Chassis.Pitch 	= IMU_Get_Data.IMU_Eular[0];
	Chassis.Yaw 	= IMU_Get_Data.IMU_Eular[2];
	Chassis.Gyo_y	= IMU_Get_Data.IMU_Gyo[1]/10;//��10
	Chassis.Gyo_z = IMU_Get_Data.IMU_Gyo[2]/10;
	Chassis.speed_x = -(Chassis.Motor_Date[0].Speed - Chassis.Motor_Date[1].Speed) /57.29578f*Diameter_weel/2.0f/2.0f;
	Chassis.omega_z =  (Chassis.Motor_Date[0].Speed + Chassis.Motor_Date[1].Speed) /57.29578f*Diameter_weel/2.0f/2.0f;
	Chassis.pose_x += 	Chassis.speed_x * 0.001f;
	Chassis.X_Target = 	RC_CH3 /6;
	Chassis.Y_Target =	RC_CH2;
	Chassis.Z_Target =  RC_CH0*10;
	

	angle -= RC_CH0 * 0.0005;
	YAW_Angle_Over_Zero(&angle);
	
}


void Chassis_Balance(void)
{
	
	Chassis.pose_x =0; 
	/*ƽ��*/
	PID_Position(&Chassis.PID.PID_b3,0,Chassis.Pitch);
	PID_Position(&Chassis.PID.PID_b4,0,Chassis.Gyo_y);
	/*��ת*/
	PID_Position(&Chassis.PID.PID_b5,angle,Chassis.Yaw);
	PID_Position(&Chassis.PID.PID_b6,Chassis.PID.PID_b5.PID_Output,Chassis.Gyo_z);

	Chassis.torque_balance = (Chassis.PID.PID_b3.PID_Output+Chassis.PID.PID_b4.PID_Output) * Chassis.torque_const;
	Chassis.torque_revolve = -Chassis.PID.PID_b6.PID_Output * Chassis.torque_const;				//��������
	PID_Position(&Chassis.PID.Chasssis_OUT,Chassis.torque_balance,0);
	Chassis.iqControl[0] = -Chassis.PID.Chasssis_OUT.PID_Output + Chassis.torque_revolve;
	Chassis.iqControl[1] =  Chassis.PID.Chasssis_OUT.PID_Output + Chassis.torque_revolve;
//	Chassis.iqControl[0] = Chassis.torque_revolve;
//	Chassis.iqControl[1] = Chassis.torque_revolve;
//	Chassis.iqControl[0] = -Chassis.PID.Chasssis_OUT.PID_Output;
//	Chassis.iqControl[1] =  Chassis.PID.Chasssis_OUT.PID_Output;
}


/**
  * @brief  ��������ģʽ
  */
void Chassis_Normal(void)
{
//	Chassis.PID.PID_b2.PID_Param.I = 0.01f;//0.01f;
//	Chassis.PID.PID_b2.PID_Output_Max = 25.0f;//25.0f;
//	chassis_ctrl.follow_gimbal_zero=CHASSIS_FOLLOW_GIMBAL_ANGLE_ZERO;
	Chassis.target_pose_x=Chassis.pose_x;
//	Chassis.flag_clear_pose = 0;
//	Chassis.target_speed_x=fabs(arm_cos_f32(PID_LQR_k5.error[0])) * speed_control(chassis_ctrl.move_speed,chassis_ctrl.move_direction);
	

	PID_Position(&Chassis.PID.PID_b1, Chassis.pose_x, Chassis.target_pose_x);
	PID_Position(&Chassis.PID.PID_b2, Chassis.speed_x, Chassis.X_Target);
	//Blance
	PID_Position(&Chassis.PID.PID_b3, Chassis.Pitch, 0);
	PID_Position(&Chassis.PID.PID_b4, Chassis.Gyo_y, 0);
	
	/*��ת*/
	PID_Position(&Chassis.PID.PID_b5,angle,Chassis.Yaw);
	PID_Position(&Chassis.PID.PID_b6,Chassis.PID.PID_b5.PID_Output,Chassis.Gyo_z);
	
	
	Chassis.torque_speed =  (-Chassis.PID.PID_b1.PID_Output + Chassis.PID.PID_b2.PID_Output) * 8;
	Chassis.torque_balance = (Chassis.PID.PID_b3.PID_Output +	Chassis.PID.PID_b4.PID_Output) * Chassis.torque_const;
	Chassis.torque_revolve = -Chassis.PID.PID_b6.PID_Output * Chassis.torque_const;				//��������
	
		
	PID_Position(&Chassis.PID.Chasssis_OUT, 0, Chassis.torque_speed + Chassis.torque_balance);

//	PID_Position(&Chassis.PID.Chasssis_OUT, 0, Chassis.torque_speed);

	Chassis.iqControl[0] = -Chassis.PID.Chasssis_OUT.PID_Output + Chassis.torque_revolve;
	Chassis.iqControl[1] =  Chassis.PID.Chasssis_OUT.PID_Output + Chassis.torque_revolve;
	
	
//	Chassis.iqControl[0] = -Chassis.PID.Chasssis_OUT.PID_Output;
//	Chassis.iqControl[1] =  Chassis.PID.Chasssis_OUT.PID_Output;
}


/**
* @brief ����PID�����ܺ���
* @param 
*/
void Chassis_InitPID(void)
{
	Chassis_PID_Set(&Chassis.PID);
}


/**
 * @brief PID��ʼ��
 * @param 
 */
void Chassis_PID_Set(PID_Chassis_Info_t *str)
{
  static int length = sizeof(PID_Parameter_t);
	memcpy(&(str->PID_b1),&Param_1,length);
	memcpy(&(str->PID_b2),&Param_2,length);
	memcpy(&(str->PID_b3),&Param_3,length);
	memcpy(&(str->PID_b4),&Param_4,length);
	memcpy(&(str->PID_b5),&Param_5,length);
	memcpy(&(str->PID_b6),&Param_6,length);
	memcpy(&(str->Chasssis_OUT),&Chasssis_OUT,length);
};



/**
 * @brief ж������
 * @param 
 */
void Chassis_Stop(void)
{
	static int16_t pid_out[CHAS_MOTOR_CNT] = {0,0};
	/* �ٶȻ�������� */
	pid_out[MF9025_R] = 0;
	pid_out[MF9025_L] = 0;
	CAN_cmd_chassis(pid_out[MF9025_R],pid_out[MF9025_L]);	  
}


/**
 * @brief YAW��Ƕȹ��㴦��
 * @param 
 */
float YAW_Angle_Over_Zero(float *Angle)
{
	if(*Angle - Chassis.Yaw > IMU_180)    
	{
		*Angle =*Angle - IMU_360;        
	}
	else if(*Angle - Chassis.Yaw < -IMU_180)
	{
		*Angle =*Angle + IMU_360;
	}
	return *Angle;
}

